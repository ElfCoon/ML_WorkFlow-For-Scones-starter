#Lambda Function 2 - Image Classifier

import json
import base64
import boto3

# Using low-level client representing Amazon SageMaker Runtime 
runtime_client = boto3.client('sagemaker-runtime')                   


# Fill this in with the name of your deployed model
ENDPOINT = "image-classification-2023-02-19-06-03-57-634" 


def lambda_handler(event, context):

    # Decode the image data
    image = base64.b64decode(event['image_data'])     

    # Instantiate a Predictor (Here we have renamed 'Predictor' to 'response')
    # Response after invoking a deployed endpoint via SageMaker Runtime 
    response = runtime_client.invoke_endpoint(
                                        EndpointName=ENDPOINT,   
                                        Body=image,               
                                        ContentType='image/png'   
                                    )
                                    
    
    # Make a prediction: Unpack reponse
    
    inferences = json.loads(response['Body'].read().decode('utf-8'))     
  
    
    # We return the data back to the Step Function    
    event['inferences'] = inferences                          
    return {
        'statusCode': 200,
        'body': event                         
    }